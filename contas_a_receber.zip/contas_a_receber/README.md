# ERP Torra Torra — Módulo Contas a Receber

## 1. Apresentação

Este projeto foi desenvolvido como parte do Projeto Integrado Multidisciplinar (PIM II) do curso de Análise e Desenvolvimento de Sistemas da UNIP.

O sistema implementa o módulo **Contas a Receber** do ERP fictício Torra Torra, desenvolvido em linguagem C, com integração ao PostgreSQL para armazenamento dos dados financeiros e ao MongoDB para registro de eventos de auditoria.

O módulo permite consultar títulos de recebimento, gerar parcelas e registrar o pagamento de uma ou mais parcelas.

## 2. Funcionalidades implementadas

- Validação das formas de pagamento disponíveis.
- Consulta de títulos pelo identificador.
- Verificação da consistência do título com os dados da venda.
- Consulta das parcelas vinculadas ao título.
- Geração de 1 a 12 parcelas.
- Distribuição do valor total entre as parcelas, considerando diferenças de centavos.
- Cálculo dos vencimentos das parcelas.
- Seleção de uma ou mais parcelas em aberto para pagamento.
- Registro do recebimento financeiro.
- Associação do recebimento às parcelas correspondentes.
- Atualização do status das parcelas para `QUITADA`.
- Atualização do título para `QUITADO` quando todas as parcelas estiverem quitadas.
- Registro de eventos de auditoria no MongoDB, incluindo o valor total recebido.

## 3. Tecnologias utilizadas

- **Linguagem de programação:** C.
- **Banco de dados relacional:** PostgreSQL.
- **Banco de dados de auditoria:** MongoDB.
- **Biblioteca PostgreSQL:** libpq.
- **Biblioteca MongoDB:** MongoDB C Driver.
- **Compilador:** GCC.
- **Ambiente de desenvolvimento:** Visual Studio Code e MSYS2 UCRT64.

## 4. Estrutura do projeto

```text
contas_a_receber/
├── README.md
├── include/
│   ├── auditoria.h
│   ├── banco_dados.h
│   ├── formas_pagamento.h
│   ├── recebimentos.h
│   ├── regras_financeiras.h
│   └── titulos_receber.h
└── src/
    ├── auditoria.c
    ├── banco_dados.c
    ├── formas_pagamento.c
    ├── main.c
    ├── recebimentos.c
    ├── regras_financeiras.c
    └── titulos_receber.c
```

A pasta `include` contém os arquivos de cabeçalho, responsáveis pelas declarações das funções. A pasta `src` contém suas respectivas implementações e o programa principal.

## 5. Organização dos módulos

| Arquivo | Responsabilidade |
|---|---|
| `main.c` | Controla o fluxo de execução e a interação com o usuário. |
| `banco_dados.c` | Gerencia a conexão e a execução de comandos SQL no PostgreSQL. |
| `titulos_receber.c` | Consulta títulos, valida sua consistência e gera parcelas. |
| `recebimentos.c` | Registra os recebimentos e atualiza os status das parcelas e dos títulos. |
| `formas_pagamento.c` | Verifica se a forma de pagamento está cadastrada e ativa. |
| `regras_financeiras.c` | Implementa funções auxiliares de conversão monetária e cálculos financeiros. |
| `auditoria.c` | Registra os eventos de recebimento no MongoDB. |

## 6. Requisitos para execução

Para compilar e executar o projeto, são necessários:

- GCC.
- PostgreSQL.
- Biblioteca de desenvolvimento libpq.
- MongoDB em execução.
- MongoDB C Driver.
- MSYS2 com o ambiente UCRT64.
- `pkg-config` configurado para localizar as bibliotecas utilizadas.

## 7. Configuração do PostgreSQL

O PostgreSQL é responsável pelo armazenamento dos dados relacionados aos títulos, parcelas e recebimentos financeiros.

A configuração utilizada pelo projeto é:

- **Host:** `localhost`
- **Porta:** `5432`
- **Banco de dados:** `TorraDB`
- **Usuário:** `postgres`
- **Schema do módulo:** `contas_a_receber`
- **Schema de referência do módulo de Vendas:** `vendas`

As configurações de conexão estão no arquivo `src/banco_dados.c`.

As tabelas utilizadas pelo módulo estão organizadas da seguinte forma:

**Schema `contas_a_receber`:**

- `titulo_receber`
- `parcela_receber`
- `recebimento_financeiro`
- `recebimento_parcela`

**Schema `vendas`:**

- `venda`
- `forma_pagamento`

O módulo Contas a Receber consulta os dados de vendas e formas de pagamento no schema `vendas`, sem modificar as tabelas pertencentes ao módulo de Vendas.

O banco `TorraDB`, os schemas, as tabelas, os relacionamentos e as permissões necessárias devem estar previamente configurados no PostgreSQL.

## 8. Configuração do MongoDB

O MongoDB é utilizado para armazenar os eventos de auditoria gerados após os recebimentos.

A conexão é realizada por meio da variável de ambiente `MONGODB_URI`.

No terminal MSYS2 UCRT64, configure:

```bash
export MONGODB_URI="mongodb://localhost:27017"
```

O módulo utiliza:

- **Banco de dados:** `erp_auditoria`
- **Coleção:** `audit_events`

Os registros de auditoria armazenam informações como:

- Identificador único do evento.
- Data e hora do registro.
- Sistema de origem.
- Setor responsável.
- Tipo do evento.
- Valor total recebido.
- Descrição contendo o identificador do título, a forma de pagamento e os identificadores das parcelas.

O campo `valor_total_recebido` é armazenado como inteiro de 64 bits (`int64`), representando o valor em centavos. Essa abordagem evita imprecisões no armazenamento e facilita operações financeiras futuras.

## 9. Regras e validações do sistema

O sistema realiza as seguintes validações:

- A forma de pagamento deve estar cadastrada e ativa.
- O título informado deve existir no banco de dados.
- A venda vinculada ao título deve estar finalizada.
- O valor total do título deve corresponder ao valor total da venda.
- A geração de parcelas permite uma quantidade entre 1 e 12.
- Não é permitida a geração de parcelas quando já existem parcelas cadastradas para o título.
- Somente parcelas em aberto podem ser selecionadas.
- Não é permitido selecionar a mesma parcela mais de uma vez no mesmo recebimento.
- As parcelas selecionadas devem pertencer ao título consultado.
- Não são permitidos pagamentos parciais ou valores superiores ao valor das parcelas.
- O recebimento e as atualizações correspondentes são executados dentro de uma transação no PostgreSQL.

Os valores monetários são convertidos e tratados internamente em centavos inteiros, utilizando o tipo `int64_t`, para evitar imprecisões em operações financeiras.

## 10. Funções financeiras

O arquivo `regras_financeiras.c` contém funções auxiliares para:

- Converter valores monetários em texto para centavos inteiros.
- Calcular juros simples de acordo com os parâmetros recebidos.
- Calcular multa por atraso.
- Calcular o valor atualizado de uma parcela.
- Distribuir o valor total entre as parcelas.
- Calcular os vencimentos das parcelas.

As funções de juros e multa estão implementadas, mas seus cálculos ainda não estão integrados ao fluxo operacional de registro de recebimentos.

## 11. Registro de recebimentos

O registro de recebimentos é realizado no PostgreSQL.

Uma operação pode quitar uma ou mais parcelas em aberto. O sistema registra o recebimento financeiro, associa os valores às parcelas correspondentes e atualiza seus status.

Quando todas as parcelas de um título estão quitadas, o status do título também é atualizado para `QUITADO`.

As operações são protegidas por transações, com confirmação ou reversão em caso de falha.

Não são permitidos pagamentos parciais, pagamentos superiores ao valor das parcelas ou geração de saldo excedente.

O sistema também calcula o valor total recebido na operação, somando os valores das parcelas selecionadas.

## 12. Auditoria

Após a confirmação do recebimento no PostgreSQL, o sistema tenta registrar o evento correspondente no MongoDB.

Cada evento de auditoria contém um identificador único, a data e hora do registro, a identificação do sistema de origem, o setor responsável, o tipo do evento e a descrição da operação.

Também é armazenado o campo `valor_total_recebido`, que representa a soma dos valores das parcelas quitadas naquela operação.

Esse valor é armazenado em centavos inteiros, utilizando o tipo `int64`, evitando problemas de precisão com números decimais.

Caso o registro da auditoria falhe, o sistema informa a ocorrência ao usuário, sem desfazer o recebimento que já foi confirmado no banco relacional.

## 13. Compilação

No terminal MSYS2 UCRT64, acesse a pasta raiz do projeto e execute:

```bash
gcc -D__USE_MINGW_ANSI_STDIO=1 -Iinclude src/main.c src/regras_financeiras.c src/banco_dados.c src/titulos_receber.c src/recebimentos.c src/formas_pagamento.c src/auditoria.c -o programa.exe -lpq $(pkg-config --cflags --libs mongoc2)
```

## 14. Execução

Antes de executar o programa, verifique se:

- O PostgreSQL está em execução.
- O MongoDB está em execução.
- O banco `TorraDB` e as tabelas necessárias estão disponíveis.
- Os schemas `contas_a_receber` e `vendas` estão configurados.
- A variável de ambiente `MONGODB_URI` está configurada.

Para iniciar o sistema:

```bash
./programa.exe
```

A execução ocorre pelo terminal, seguindo as instruções apresentadas pelo próprio programa.

## 15. Considerações finais

O módulo Contas a Receber foi desenvolvido para integrar o ERP Torra Torra, utilizando a linguagem C e os bancos de dados PostgreSQL e MongoDB.

A solução permite consultar títulos, gerar parcelas, registrar recebimentos e manter o histórico de auditoria das operações, incluindo o valor total recebido em cada evento.

A organização em arquivos de implementação e cabeçalho favorece a separação de responsabilidades e a manutenção do código.

O projeto utiliza o banco de dados `TorraDB`, com o schema próprio `contas_a_receber` e integração de consulta ao schema `vendas`.