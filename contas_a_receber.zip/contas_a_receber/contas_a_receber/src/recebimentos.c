#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "banco_dados.h"
#include "regras_financeiras.h"
#include "recebimentos.h"

static void reverter_transacao(PGconn *conexao) {
    PGresult *resultado = executar_sql(
        conexao,
        "ROLLBACK",
        0,
        NULL
    );

    if (resultado != NULL) {
        PQclear(resultado);
    }
}

int registrar_recebimento(
    PGconn *conexao,
    int id_forma_pagamento,
    const int *ids_parcelas,
    int quantidade_parcelas,
    int64_t *valor_total_recebido
) {
    if (conexao == NULL ||
        id_forma_pagamento <= 0 ||
        ids_parcelas == NULL ||
        quantidade_parcelas <= 0 ||
        quantidade_parcelas > 12 ||
        valor_total_recebido == NULL
    ) {
        return 0;
    }

    *valor_total_recebido = 0;
    PGresult *resultado = executar_sql(
        conexao,
        "BEGIN",
        0,
        NULL
    );

    if (resultado == NULL) {
        return 0;
    }

    PQclear(resultado);

    const char *parametros[] = {
        NULL
    };

    char id_forma_texto[12];

    snprintf(
        id_forma_texto,
        sizeof(id_forma_texto),
        "%d",
        id_forma_pagamento
    );

    parametros[0] = id_forma_texto;

    const char *sql_forma_pagamento =
        "SELECT id_forma_pagamento "
        "FROM vendas.forma_pagamento "
        "WHERE id_forma_pagamento = $1 "
        "AND ativo = TRUE";

    resultado = executar_sql(
        conexao,
        sql_forma_pagamento,
        1,
        parametros
    );

    if (resultado == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    if (PQntuples(resultado) != 1) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    PQclear(resultado);

    int64_t valor_total_centavos = 0;

    char id_parcela_texto[12];

    const char *parametros_parcela[] = {
        id_parcela_texto
    };
    for (int i = 0; i < quantidade_parcelas; i++) {
        if (ids_parcelas[i] <= 0) {
            reverter_transacao(conexao);
            return 0;
        }
        for (int j = 0; j < i; j++) {
            if (ids_parcelas[i] == ids_parcelas[j]) {
                reverter_transacao(conexao);
                return 0;
            }
        }
        snprintf(
            id_parcela_texto,
            sizeof(id_parcela_texto),
            "%d",
            ids_parcelas[i]
        );
        const char *sql_parcela =
            "SELECT valor, status "
            "FROM contas_receber.parcela_receber "
            "WHERE id_parcela_receber = $1 "
            "FOR UPDATE";

        resultado = executar_sql(
            conexao,
            sql_parcela,
            1,
            parametros_parcela
        );

        if (resultado == NULL) {
            reverter_transacao(conexao);
            return 0;
        }
        if (PQntuples(resultado) != 1) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }
        if (strcmp(PQgetvalue(resultado, 0, 1), "EM_ABERTO") != 0) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }
        int64_t valor_parcela_centavos;

        if (!texto_para_centavos(
                PQgetvalue(resultado, 0, 0),
                &valor_parcela_centavos
            )) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }

        if (valor_parcela_centavos <= 0) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }

        PQclear(resultado);

        if (valor_total_centavos > INT64_MAX - valor_parcela_centavos) {
            reverter_transacao(conexao);
            return 0;
        }

        valor_total_centavos += valor_parcela_centavos;
    }
    if (valor_total_centavos <= 0) {
        reverter_transacao(conexao);
        return 0;
    }
    char valor_total_texto[32];

    snprintf(
        valor_total_texto,
        sizeof(valor_total_texto),
        "%lld.%02lld",
        (long long)(valor_total_centavos / 100),
        (long long)(valor_total_centavos % 100)
    );
    time_t agora = time(NULL);

    struct tm *data_hora = localtime(&agora);

    if (data_hora == NULL) {
        reverter_transacao(conexao);
        return 0;
    }
    char data_recebimento_texto[20];

    if (strftime(
            data_recebimento_texto,
            sizeof(data_recebimento_texto),
            "%Y-%m-%d %H:%M:%S",
            data_hora
        ) == 0) {
        reverter_transacao(conexao);
        return 0;
    }
    const char *parametros_recebimento[] = {
        id_forma_texto,
        data_recebimento_texto,
        valor_total_texto
    };
    const char *sql_recebimento =
        "INSERT INTO contas_receber.recebimento_financeiro ("
        "id_forma_pagamento, "
        "data_recebimento, "
        "valor_recebido"
        ") VALUES ($1, $2, $3) "
        "RETURNING id_recebimento_financeiro";
    
    resultado = executar_sql(
        conexao,
        sql_recebimento,
        3,
        parametros_recebimento
    );

    if (resultado == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    if (PQntuples(resultado) != 1) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }
    char id_recebimento_texto[32];

    if (snprintf(
            id_recebimento_texto,
            sizeof(id_recebimento_texto),
            "%s",
            PQgetvalue(resultado, 0, 0)
        ) >= sizeof(id_recebimento_texto)) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    PQclear(resultado);
    const char *sql_associar_parcela =
        "INSERT INTO contas_receber.recebimento_parcela ("
        "id_recebimento_financeiro, "
        "id_parcela_receber, "
        "valor_aplicado"
        ") VALUES ($1, $2, $3)";
    char valor_parcela_texto[32];

    const char *parametros_associacao[] = {
        id_recebimento_texto,
        id_parcela_texto,
        valor_parcela_texto
    };
    for (int i = 0; i < quantidade_parcelas; i++) {
        snprintf(
            id_parcela_texto,
            sizeof(id_parcela_texto),
            "%d",
            ids_parcelas[i]
        );
        const char *sql_consultar_valor =
            "SELECT valor "
            "FROM contas_receber.parcela_receber "
            "WHERE id_parcela_receber = $1";

        resultado = executar_sql(
            conexao,
            sql_consultar_valor,
            1,
            parametros_parcela
        );

        if (resultado == NULL) {
            reverter_transacao(conexao);
            return 0;
        }
        if (PQntuples(resultado) != 1) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }
        int64_t valor_parcela_centavos;

        if (!texto_para_centavos(
                PQgetvalue(resultado, 0, 0),
                &valor_parcela_centavos
            )) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }

        if (valor_parcela_centavos <= 0) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }

        snprintf(
            valor_parcela_texto,
            sizeof(valor_parcela_texto),
            "%lld.%02lld",
            (long long)(valor_parcela_centavos / 100),
            (long long)(valor_parcela_centavos % 100)
        );

        PQclear(resultado);
        resultado = executar_sql(
            conexao,
            sql_associar_parcela,
            3,
            parametros_associacao
        );

        if (resultado == NULL) {
            reverter_transacao(conexao);
            return 0;
        }

        PQclear(resultado);
        const char *sql_atualizar_parcela =
            "UPDATE contas_receber.parcela_receber "
            "SET status = 'QUITADA' "
            "WHERE id_parcela_receber = $1 "
            "AND status = 'EM_ABERTO'";

        resultado = executar_sql(
            conexao,
            sql_atualizar_parcela,
            1,
            parametros_parcela
        );

        if (resultado == NULL) {
            reverter_transacao(conexao);
            return 0;
        }
        if (strcmp(PQcmdTuples(resultado), "1") != 0) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }

        PQclear(resultado);

        const char *sql_atualizar_conta =
            "UPDATE contas_pagar.conta_bancaria "
            "SET saldo_atual = saldo_atual + $1::NUMERIC "
            "WHERE ativo = TRUE "
            "RETURNING id_conta_bancaria";

        const char *parametros_conta[] = {
            valor_parcela_texto
        };

        resultado = executar_sql(
            conexao,
            sql_atualizar_conta,
            1,
            parametros_conta
        );

        if (resultado == NULL) {
            reverter_transacao(conexao);
            return 0;
        }

        if (PQntuples(resultado) != 1) {
            PQclear(resultado);
            reverter_transacao(conexao);
            return 0;
        }

        PQclear(resultado);

        const char *sql_atualizar_titulo =
            "UPDATE contas_receber.titulo_receber t "
            "SET status = 'QUITADO' "
            "WHERE t.id_titulo_receber = ("
            "    SELECT p.id_titulo_receber "
            "    FROM contas_receber.parcela_receber p "
            "    WHERE p.id_parcela_receber = $1"
            ") "
            "AND NOT EXISTS ("
            "    SELECT 1 "
            "    FROM contas_receber.parcela_receber p "
            "    WHERE p.id_titulo_receber = t.id_titulo_receber "
            "    AND p.status <> 'QUITADA'"
            ")";
        resultado = executar_sql(
            conexao,
            sql_atualizar_titulo,
            1,
            parametros_parcela
        );

        if (resultado == NULL) {
            reverter_transacao(conexao);
            return 0;
        }

        PQclear(resultado);
    }
    resultado = executar_sql(
        conexao,
        "COMMIT",
        0,
        NULL
    );

    if (resultado == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    PQclear(resultado);

    *valor_total_recebido = valor_total_centavos;
    
    return 1;
}