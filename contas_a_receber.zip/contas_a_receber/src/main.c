#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>
#include <errno.h>

#include "banco_dados.h"
#include "titulos_receber.h"
#include "recebimentos.h"
#include "formas_pagamento.h"
#include "auditoria.h"

static int ler_inteiro(int *valor) {
    char entrada[100];
    char *fim;

    if (fgets(entrada, sizeof(entrada), stdin) == NULL) {
        return 0;
    }

    errno = 0;
    long numero = strtol(entrada, &fim, 10);

    if (fim == entrada || errno == ERANGE ||
        numero < INT_MIN || numero > INT_MAX) {
        return 0;
    }

    while (*fim == ' ' || *fim == '\t' ||
           *fim == '\r') {
        fim++;
    }

    if (*fim != '\n' && *fim != '\0') {
        return 0;
    }

    *valor = (int)numero;
    return 1;
}

static void limpar_tela(void) {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

int main(void) {

    limpar_tela();
    mongoc_init();

    const char *uri_mongo = getenv("MONGODB_URI");

    if (uri_mongo == NULL || uri_mongo[0] == '\0') {
        printf("Variavel de ambiente MONGODB_URI nao configurada.\n");
        mongoc_cleanup();
        return 1;
    }

    mongoc_client_t *cliente_mongo =
        mongoc_client_new(uri_mongo);

    if (cliente_mongo == NULL) {
        printf("Falha ao criar cliente MongoDB.\n");
        mongoc_cleanup();
        return 1;
    }

    PGconn *conexao = conectar_banco();

    if (conexao == NULL) {
        mongoc_client_destroy(cliente_mongo);
        mongoc_cleanup();
        return 1;
    }

    int id_titulo_receber;
    int quantidade_parcelas;
    int id_forma_pagamento;
    int quantidade_parcelas_pagar;
    int ids_parcelas[12];
    int64_t valor_total_recebido = 0;
    printf("\n=== REGISTRO DE RECEBIMENTO ===\n");

    printf("\nInforme a forma de pagamento utilizada:\n");
    printf("1 - Dinheiro\n");
    printf("2 - Pix\n");
    printf("3 - Cartao de debito\n");
    printf("4 - Cartao de credito\n");
    printf("5 - Cartao carne da loja\n");

    while (1) {
        printf("\nDigite o numero correspondente: ");

        if (!ler_inteiro(&id_forma_pagamento) ||
            id_forma_pagamento <= 0) {
            printf("Entrada invalida. Digite o numero de uma das formas de pagamento apresentadas.\n");
            continue;
        }

        if (!validar_forma_pagamento(conexao, id_forma_pagamento)) {
            printf("A forma de pagamento selecionada nao esta disponivel. Escolha outra opcao.\n");
            continue;
        }

        break;
    }

    printf("\n=== CONSULTA DO TITULO ===\n");
    printf("Informe o numero de identificacao do titulo que deseja consultar.\n");

    PGresult *titulo = NULL;

    while (1) {
        printf("\nID do titulo: ");

        if (!ler_inteiro(&id_titulo_receber) ||
            id_titulo_receber <= 0) {
            printf("ID invalido. Informe um numero de identificacao valido.\n");
            continue;
        }

        titulo = consultar_titulo_por_id(
            conexao,
            id_titulo_receber
        );

        if (titulo == NULL) {
            printf("Erro ao consultar o titulo no banco de dados.\n");

            mongoc_client_destroy(cliente_mongo);
            mongoc_cleanup();

            desconectar_banco(conexao);
            return 1;
        }

        if (PQntuples(titulo) == 0) {
            printf("Nenhum titulo foi encontrado com esse ID. Verifique o numero informado.\n");
            PQclear(titulo);
            titulo = NULL;
            continue;
        }

        PQclear(titulo);
        titulo = NULL;
        break;
    }

    PGresult *parcelas = consultar_parcelas_titulo(
        conexao,
        id_titulo_receber
    );

    if (parcelas == NULL) {
        printf("\nErro ao consultar as parcelas.\n");

        mongoc_client_destroy(cliente_mongo);
        mongoc_cleanup();

        desconectar_banco(conexao);
        return 1;
    }

    int total_parcelas = PQntuples(parcelas);

    if (total_parcelas == 0) {
        printf("\nEste titulo ainda nao possui parcelas cadastradas.\n");
        printf("Para continuar com o recebimento, sera necessario gerar as parcelas.\n");

        while (1) {
            printf("\nEm quantas parcelas deseja dividir o titulo (1 a 12)? ");

            if (!ler_inteiro(&quantidade_parcelas) ||
                quantidade_parcelas < 1 ||
                quantidade_parcelas > 12) {
                printf("Quantidade invalida. Informe um numero entre 1 e 12.\n");
                continue;
            }

            break;
        }

        PQclear(parcelas);

        if (!gerar_parcelas_titulo(
                conexao,
                id_titulo_receber,
                quantidade_parcelas
            )) {
            printf("\nNao foi possivel gerar as parcelas.\n");
            mongoc_client_destroy(cliente_mongo);
            mongoc_cleanup();
            desconectar_banco(conexao);
            return 1;
        }

        printf("\nAs parcelas foram geradas com sucesso!\n");
        printf("Abaixo, voce pode conferir os valores e vencimentos de cada parcela.\n");
    }

    parcelas = consultar_parcelas_titulo(
        conexao,
        id_titulo_receber
    );

    if (parcelas == NULL) {
        printf("\nErro ao consultar as parcelas.\n");
        mongoc_client_destroy(cliente_mongo);
        mongoc_cleanup();
        desconectar_banco(conexao);
        return 1;
    }

    total_parcelas = PQntuples(parcelas);

    if (total_parcelas == 0) {
        printf("\nNenhuma parcela foi encontrada para este titulo.\n");
        mongoc_client_destroy(cliente_mongo);
        mongoc_cleanup();
        PQclear(parcelas);
        desconectar_banco(conexao);
        return 1;
    }

    int parcelas_em_aberto = 0;

    printf("\n=== CONSULTA DAS PARCELAS ===\n");
    printf("Confira abaixo as parcelas deste titulo e a situacao de cada uma:\n\n");

    for (int i = 0; i < total_parcelas; i++) {
        printf(
            "ID: %s | Parcela: %s | Vencimento: %s | Valor: R$ %s | Status: %s\n",
            PQgetvalue(parcelas, i, 0),
            PQgetvalue(parcelas, i, 1),
            PQgetvalue(parcelas, i, 2),
            PQgetvalue(parcelas, i, 3),
            PQgetvalue(parcelas, i, 4)
        );
    }

    for (int i = 0; i < total_parcelas; i++) {
        if (strcmp(PQgetvalue(parcelas, i, 4), "EM_ABERTO") == 0) {
            parcelas_em_aberto++;
        }
    }

    if (parcelas_em_aberto == 0) {
        printf("\nTodas as parcelas deste titulo ja foram quitadas.\n");
        mongoc_client_destroy(cliente_mongo);
        mongoc_cleanup();
        PQclear(parcelas);
        desconectar_banco(conexao);
        return 0;
    }

    printf("\nSelecione quantas parcelas deseja quitar neste recebimento.\n");
    printf("Somente parcelas em aberto podem ser selecionadas.\n");

    while (1) {
        printf("\nQuantidade de parcelas (1 a %d): ", parcelas_em_aberto);

        if (!ler_inteiro(&quantidade_parcelas_pagar) ||
            quantidade_parcelas_pagar < 1 ||
            quantidade_parcelas_pagar > parcelas_em_aberto) {
            printf("Quantidade invalida. Informe um numero entre 1 e %d.\n", parcelas_em_aberto);
            continue;
        }

        break;
    }

    for (int i = 0; i < quantidade_parcelas_pagar; i++) {
        int parcela_encontrada;
        int parcela_repetida;

        do {
            parcela_repetida = 0;
            parcela_encontrada = 0;

            printf("Digite o ID da parcela que deseja quitar (%d de %d): ", i + 1, quantidade_parcelas_pagar);

            if (!ler_inteiro(&ids_parcelas[i]) || ids_parcelas[i] <= 0) {
                printf("ID da parcela invalido.\n");
                parcela_repetida = 1;
                continue;
            }

            for (int j = 0; j < i; j++) {
                if (ids_parcelas[i] == ids_parcelas[j]) {
                    printf("Esta parcela ja foi selecionada.\n");
                    parcela_repetida = 1;
                    break;
                }
            }
            if(!parcela_repetida) {
                for (int j = 0; j < total_parcelas; j++) {
                    int id_consultado = atoi(PQgetvalue(parcelas, j, 0));
                    if (ids_parcelas[i] == id_consultado) {
                        const char *status = PQgetvalue(parcelas, j, 4);

                        if (strcmp(status, "EM_ABERTO") != 0) {
                            printf("Esta parcela ja foi quitada.\n");
                            parcela_repetida = 1;
                            break;
                        }
                        parcela_encontrada = 1;
                        break;
                    }
                }
            }

            if (!parcela_encontrada && !parcela_repetida) {
                printf("A parcela nao pertence a este titulo.\n");
                parcela_repetida = 1;
            }
        } while (parcela_repetida);
    }
    PQclear(parcelas);

    if (registrar_recebimento(
        conexao,
        id_forma_pagamento,
        ids_parcelas,
        quantidade_parcelas_pagar,
        &valor_total_recebido
    )) {

    printf("\nRecebimento registrado com sucesso!\n");
    printf("As parcelas selecionadas foram quitadas.\n");

    printf(
        "Valor total recebido: R$ %lld,%02lld\n",
        (long long)(valor_total_recebido / 100),
        (long long)(valor_total_recebido % 100)
    );

    if (registrar_auditoria(
            cliente_mongo,
            id_titulo_receber,
            id_forma_pagamento,
            ids_parcelas,
            quantidade_parcelas_pagar,
            valor_total_recebido
        )) {

        printf("Operacao registrada no historico de auditoria.\n");

    } else {

        printf("Recebimento salvo, mas houve falha no registro da auditoria.\n");
    }

} else {

    printf("\nNao foi possivel registrar o recebimento.\n");

    desconectar_banco(conexao);
    mongoc_client_destroy(cliente_mongo);
    mongoc_cleanup();

    return 1;
}

    printf("\nOperacao finalizada.\n");
    desconectar_banco(conexao);
    mongoc_client_destroy(cliente_mongo);
    mongoc_cleanup();

    return 0;
}