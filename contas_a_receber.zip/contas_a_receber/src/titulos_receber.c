#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "titulos_receber.h"
#include "banco_dados.h"
#include "regras_financeiras.h"


PGresult *consultar_titulo_por_venda_pagamento(
    PGconn *conexao,
    int id_venda_pagamento
) {
    if (conexao == NULL || id_venda_pagamento <= 0) {
        return NULL;
    }

    const char *sql =
        "SELECT "
        "id_titulo_receber, "
        "id_venda, "
        "id_venda_pagamento, "
        "id_cliente, "
        "id_usuario, "
        "data_emissao, "
        "valor_total, "
        "quantidade_parcelas, "
        "status "
        "FROM contas_receber.titulo_receber "
        "WHERE id_venda_pagamento = $1;";

    char id_texto[12];

    snprintf(
        id_texto,
        sizeof(id_texto),
        "%d",
        id_venda_pagamento
    );

    const char *parametros[] = {id_texto};

    PGresult *resultado = executar_sql(
        conexao,
        sql,
        1,
        parametros
    );

    if (resultado == NULL) {
        return NULL;
    }

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        PQclear(resultado);
        return NULL;
    }

    return resultado;
}

PGresult *consultar_titulo_por_id(
    PGconn *conexao,
    int id_titulo_receber
) {
    if (conexao == NULL || id_titulo_receber <= 0) {
        return NULL;
    }

    const char *sql =
        "SELECT "
        "id_titulo_receber, "
        "id_venda, "
        "id_venda_pagamento, "
        "id_cliente, "
        "id_usuario, "
        "data_emissao, "
        "valor_total, "
        "quantidade_parcelas, "
        "status "
        "FROM contas_receber.titulo_receber "
        "WHERE id_titulo_receber = $1;";

    char id_texto[12];

    snprintf(
        id_texto,
        sizeof(id_texto),
        "%d",
        id_titulo_receber
    );

    const char *parametros[] = {id_texto};

    PGresult *resultado = executar_sql(
        conexao,
        sql,
        1,
        parametros
    );

    if (resultado == NULL) {
        return NULL;
    }

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        PQclear(resultado);
        return NULL;
    }

    return resultado;
}

int validar_consistencia_titulo(
    PGconn *conexao,
    int id_venda_pagamento,
    int id_venda,
    int id_cliente,
    const char *valor_titulo
) {
    if (conexao == NULL ||
        id_venda_pagamento <= 0 ||
        id_cliente <= 0 ||
        id_venda <= 0 ||
        valor_titulo == NULL) {
        return -1;
    }

    const char *sql =
        "SELECT "
        "v.id_cliente, "
        "vp.id_venda, "
        "vp.valor_pago, "
        "v.status, "
        "fp.id_forma_pagamento, "
        "fp.ativo "
        "FROM vendas.tb_venda_pagamento vp "
        "INNER JOIN vendas.tb_venda v "
        "ON v.id_venda = vp.id_venda "
        "INNER JOIN vendas.tb_forma_pagamento fp "
        "ON fp.id_forma_pagamento = vp.id_forma_pagamento "
        "WHERE vp.id_venda_pagamento = $1;";

    char id_texto[12];

    snprintf(
        id_texto,
        sizeof(id_texto),
        "%d",
        id_venda_pagamento
    );

    const char *parametros[] = {id_texto};

    PGresult *resultado = executar_sql(
        conexao,
        sql,
        1,
        parametros
    );

    if (resultado == NULL) {
        return -1;
    }

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        PQclear(resultado);
        return -1;
    }

    if (PQntuples(resultado) != 1) {
        PQclear(resultado);
        return 0;
    }

    int cliente_venda = atoi(PQgetvalue(resultado, 0, 0));
    int id_venda_pagamento_venda = atoi(PQgetvalue(resultado, 0, 1));
    const char *valor_pagamento = PQgetvalue(resultado, 0, 2);
    const char *status_venda = PQgetvalue(resultado, 0, 3);
    int id_forma_pagamento = atoi(PQgetvalue(resultado, 0, 4));
    int forma_ativa = strcmp(PQgetvalue(resultado, 0, 5), "t") == 0;

    int64_t centavos_titulo;
    int64_t centavos_pagamento;

    int conversao_titulo = texto_para_centavos(
        valor_titulo,
        &centavos_titulo
    );

    int conversao_pagamento = texto_para_centavos(
        valor_pagamento,
        &centavos_pagamento
    );

    int forma_parcelavel =
        id_forma_pagamento == 4 ||
        id_forma_pagamento == 5;

    int consistente =
        cliente_venda == id_cliente &&
        id_venda_pagamento_venda == id_venda &&
        strcmp(status_venda, "CONFIRMADO") == 0 &&
        forma_ativa &&
        forma_parcelavel &&
        conversao_titulo &&
        conversao_pagamento &&
        centavos_titulo == centavos_pagamento;

    PQclear(resultado);

    return consistente ? 1 : 0;
}


static void reverter_transacao(PGconn *conexao) {
    PGresult *reversao = executar_sql(
        conexao,
        "ROLLBACK;",
        0,
        NULL
    );

    if (reversao != NULL) {
        PQclear(reversao);
    }
}


int gerar_parcelas_titulo(
    PGconn *conexao,
    int id_titulo_receber,
    int id_usuario,
    int quantidade_parcelas_solicitada
) {
    if (
        conexao == NULL ||
        id_titulo_receber <= 0 ||
        id_usuario <= 0 ||
        quantidade_parcelas_solicitada < 1 ||
        quantidade_parcelas_solicitada > 12
    ) {
        return 0;
    }

    PGresult *inicio = executar_sql(
        conexao,
        "BEGIN;",
        0,
        NULL
    );

    if (inicio == NULL) {
        return 0;
    }

    if (PQresultStatus(inicio) != PGRES_COMMAND_OK) {
        PQclear(inicio);
        return 0;
    }

    PQclear(inicio);

    const char *sql =
        "SELECT "
        "t.id_venda_pagamento, "
        "t.id_venda, "
        "t.id_cliente, "
        "t.valor_total, "
        "t.status, "
        "TO_CHAR(v.data_venda, 'YYYY-MM-DD'), "
        "v.status, "
        "u.status "
        "FROM contas_receber.titulo_receber t "
        "INNER JOIN vendas.tb_venda v "
        "ON v.id_venda = t.id_venda "
        "INNER JOIN seguranca_ti.usuario u "
        "ON u.id_usuario = $2 "
        "AND u.status = 'ATIVO' "
        "WHERE t.id_titulo_receber = $1 "
        "FOR UPDATE OF t;";

    char id_titulo_texto[12];
    char id_usuario_texto[12];

    snprintf(
        id_titulo_texto,
        sizeof(id_titulo_texto),
        "%d",
        id_titulo_receber
    );

    snprintf(
        id_usuario_texto,
        sizeof(id_usuario_texto),
        "%d",
        id_usuario
    );

    const char *parametros[] = {
        id_titulo_texto,
        id_usuario_texto
    };

    PGresult *resultado = executar_sql(
        conexao,
        sql,
        2,
        parametros
    );

    if (resultado == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    if (PQntuples(resultado) != 1 || PQnfields(resultado) != 8) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    int id_venda_pagamento = atoi(
        PQgetvalue(resultado, 0, 0)
    );

    int id_venda = atoi(
        PQgetvalue(resultado, 0, 1)
    );

    int id_cliente = atoi(
        PQgetvalue(resultado, 0, 2)
    );

    const char *valor_titulo = PQgetvalue(
        resultado,
        0,
        3
    );

    const char *status_titulo = PQgetvalue(
        resultado,
        0,
        4
    );

    const char *data_venda = PQgetvalue(
        resultado,
        0,
        5
    );

    const char *status_venda = PQgetvalue(
        resultado,
        0,
        6
    );

    const char *status_usuario = PQgetvalue(
        resultado,
        0,
        7
    );

    if (
        strcmp(status_venda, "CONFIRMADO") != 0 ||
        strcmp(status_titulo, "EM_ABERTO") != 0 ||
        strcmp(status_usuario, "ATIVO") != 0
    ) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    char data_venda_texto[11];

    snprintf(
        data_venda_texto,
        sizeof(data_venda_texto),
        "%s",
        data_venda
    );

    int consistencia = validar_consistencia_titulo(
        conexao,
        id_venda_pagamento,
        id_venda,
        id_cliente,
        valor_titulo
    );

    if (consistencia != 1) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    int64_t valor_total_centavos;

    if (!texto_para_centavos(
        valor_titulo,
        &valor_total_centavos
    )) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    if (valor_total_centavos < quantidade_parcelas_solicitada) {
        PQclear(resultado);
        reverter_transacao(conexao);
        return 0;
    }

    PQclear(resultado);

    const char *sql_verificar =
        "SELECT COUNT(*) "
        "FROM contas_receber.parcela_receber "
        "WHERE id_titulo_receber = $1;";

    const char *parametros_verificacao[] = {
        id_titulo_texto
    };

    PGresult *resultado_verificacao = executar_sql(
        conexao,
        sql_verificar,
        1,
        parametros_verificacao
    );

    if (resultado_verificacao == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    if (
        PQresultStatus(resultado_verificacao) != PGRES_TUPLES_OK ||
        PQntuples(resultado_verificacao) != 1 ||
        PQnfields(resultado_verificacao) != 1
    ) {
        PQclear(resultado_verificacao);
        reverter_transacao(conexao);
        return 0;
    }

    int parcelas_existentes = atoi(
        PQgetvalue(resultado_verificacao, 0, 0)
    );

    PQclear(resultado_verificacao);

    if (parcelas_existentes > 0) {
        reverter_transacao(conexao);
        return 0;
    }

    char quantidade_texto[4];

    snprintf(
        quantidade_texto,
        sizeof(quantidade_texto),
        "%d",
        quantidade_parcelas_solicitada
    );

    const char *sql_atualizar =
        "UPDATE contas_receber.titulo_receber "
        "SET quantidade_parcelas = $2 "
        "WHERE id_titulo_receber = $1;";

    const char *parametros_atualizar[] = {
        id_titulo_texto,
        quantidade_texto
    };

    PGresult *atualizacao = executar_sql(
        conexao,
        sql_atualizar,
        2,
        parametros_atualizar
    );

    if (atualizacao == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    if (PQresultStatus(atualizacao) != PGRES_COMMAND_OK) {
        PQclear(atualizacao);
        reverter_transacao(conexao);
        return 0;
    }

    if (
        PQcmdTuples(atualizacao)[0] == '\0' ||
        atoi(PQcmdTuples(atualizacao)) != 1
    ) {
        PQclear(atualizacao);
        reverter_transacao(conexao);
        return 0;
    }

    PQclear(atualizacao);

    if (
        (size_t)quantidade_parcelas_solicitada >
        SIZE_MAX / sizeof(int64_t)
    ) {
        reverter_transacao(conexao);
        return 0;
    }

    int64_t *valores_parcelas = malloc(
        (size_t)quantidade_parcelas_solicitada *
        sizeof(int64_t)
    );

    if (valores_parcelas == NULL) {
        reverter_transacao(conexao);
        return 0;
    }

    if (!distribuir_valor_parcelas(
        valor_total_centavos,
        quantidade_parcelas_solicitada,
        valores_parcelas
    )) {
        free(valores_parcelas);
        reverter_transacao(conexao);
        return 0;
    }

    char vencimento[11];

    for (
        int i = 1;
        i <= quantidade_parcelas_solicitada;
        i++
    ) {
        int64_t valor_parcela_centavos =
            valores_parcelas[i - 1];

        if (valor_parcela_centavos <= 0) {
            free(valores_parcelas);
            reverter_transacao(conexao);
            return 0;
        }

        char valor_parcela[32];

        snprintf(
            valor_parcela,
            sizeof(valor_parcela),
            "%lld.%02lld",
            (long long)(valor_parcela_centavos / 100),
            (long long)(valor_parcela_centavos % 100)
        );

        char numero_parcela[12];

        snprintf(
            numero_parcela,
            sizeof(numero_parcela),
            "%d",
            i
        );

        if (!calcular_vencimento_parcela(
            data_venda_texto,
            i,
            vencimento,
            sizeof(vencimento)
        )) {
            free(valores_parcelas);
            reverter_transacao(conexao);
            return 0;
        }

        const char *sql_inserir =
            "INSERT INTO contas_receber.parcela_receber ("
            "id_titulo_receber, "
            "id_usuario, "
            "numero_parcela, "
            "vencimento, "
            "valor, "
            "status"
            ") VALUES ($1, $2, $3, $4, $5, $6);";

        const char *parametros_inserir[] = {
            id_titulo_texto,
            id_usuario_texto,
            numero_parcela,
            vencimento,
            valor_parcela,
            "EM_ABERTO"
        };

        PGresult *insercao = executar_sql(
            conexao,
            sql_inserir,
            6,
            parametros_inserir
        );

        if (insercao == NULL) {
            free(valores_parcelas);
            reverter_transacao(conexao);
            return 0;
        }

        if (PQresultStatus(insercao) != PGRES_COMMAND_OK) {
            PQclear(insercao);
            free(valores_parcelas);
            reverter_transacao(conexao);
            return 0;
        }

        PQclear(insercao);
    }

    PGresult *confirmacao = executar_sql(
        conexao,
        "COMMIT;",
        0,
        NULL
    );

    if (confirmacao == NULL) {
        free(valores_parcelas);
        reverter_transacao(conexao);
        return 0;
    }

    if (PQresultStatus(confirmacao) != PGRES_COMMAND_OK) {
        PQclear(confirmacao);
        free(valores_parcelas);
        reverter_transacao(conexao);
        return 0;
    }

    PQclear(confirmacao);
    free(valores_parcelas);

    return 1;
}



PGresult *consultar_parcelas_titulo(
    PGconn *conexao,
    int id_titulo_receber
) {
    if (conexao == NULL || id_titulo_receber <= 0) {
        return NULL;
    }

    char id_titulo_texto[12];

    snprintf(
        id_titulo_texto,
        sizeof(id_titulo_texto),
        "%d",
        id_titulo_receber
    );

    const char *parametros[] = {
        id_titulo_texto
    };

    const char *sql =
        "SELECT "
        "id_parcela_receber, "
        "id_titulo_receber, "
        "id_usuario, "
        "numero_parcela, "
        "vencimento, "
        "valor, "
        "status "
        "FROM contas_receber.parcela_receber "
        "WHERE id_titulo_receber = $1 "
        "ORDER BY numero_parcela;";

    PGresult *resultado = executar_sql(
        conexao,
        sql,
        1,
        parametros
    );

    if (resultado == NULL) {
        return NULL;
    }

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        PQclear(resultado);
        return NULL;
    }

    return resultado;
}