#include <stdio.h>
#include <mongoc/mongoc.h>
#include <time.h>
#include <stdint.h>

#include "auditoria.h"

int registrar_auditoria(
    mongoc_client_t *cliente,
    int id_titulo_receber,
    int id_forma_pagamento,
    const int *ids_parcelas,
    int quantidade_parcelas,
    int64_t valor_total_recebido
) {

    if (cliente == NULL ||
        ids_parcelas == NULL ||
        id_titulo_receber <= 0 ||
        id_forma_pagamento <= 0 ||
        quantidade_parcelas <= 0 ||
        quantidade_parcelas > 12 ||
        valor_total_recebido <= 0) {
        return 0;
    }

    for (int i = 0; i < quantidade_parcelas; i++) {
        if (ids_parcelas[i] <= 0) {
            return 0;
        }
    }

    mongoc_collection_t *colecao =
        mongoc_client_get_collection(
            cliente,
            "erp_auditoria",
            "audit_events"
        );

    if (colecao == NULL) {
        return 0;
    }

    bson_t documento;
    bson_init(&documento);

    // Identificador único do evento
    bson_oid_t oid;
    char id_evento[25];

    bson_oid_init(&oid, NULL);
    bson_oid_to_string(&oid, id_evento);

    BSON_APPEND_UTF8(&documento, "id_evento", id_evento);

    BSON_APPEND_INT64(&documento, "valor_total_recebido", valor_total_recebido);

    // Identificação da origem
    BSON_APPEND_UTF8(&documento, "sistema_origem", "ERP_TORRA");

    // Data e hora em UTC
    time_t agora = time(NULL);

    BSON_APPEND_DATE_TIME(&documento, "data_hora", (int64_t) agora * 1000);

    // Identificação do setor e do evento
    BSON_APPEND_UTF8(&documento, "setor", "CONTAS_A_RECEBER");

    BSON_APPEND_UTF8(&documento, "tipo", "RECEBIMENTO_REGISTRADO");

    // Descrição do recebimento
    char descricao[512];

    int tamanho = snprintf(
        descricao,
        sizeof(descricao),
        "Recebimento registrado. Titulo: %d; "
        "Forma de pagamento: %d; Parcelas: ",
        id_titulo_receber,
        id_forma_pagamento
    );

    if (tamanho < 0 || (size_t)tamanho >= sizeof(descricao)) {
        bson_destroy(&documento);
        mongoc_collection_destroy(colecao);
        return 0;
    }

    size_t usado = (size_t)tamanho;

    for (int i = 0; i < quantidade_parcelas; i++) {

        tamanho = snprintf(
            descricao + usado,
            sizeof(descricao) - usado,
            "%s%d",
            i == 0 ? "" : ", ",
            ids_parcelas[i]
        );

        if (tamanho < 0 ||
            (size_t)tamanho >= sizeof(descricao) - usado) {

            bson_destroy(&documento);
            mongoc_collection_destroy(colecao);
            return 0;
        }

        usado += (size_t)tamanho;
    }

    BSON_APPEND_UTF8(&documento, "descricao", descricao);

    bson_error_t erro;

    int sucesso = mongoc_collection_insert_one(
        colecao,
        &documento,
        NULL,
        NULL,
        &erro
    );

    if (!sucesso) {
        printf("Falha ao registrar evento de auditoria.\n");
    }

    bson_destroy(&documento);
    mongoc_collection_destroy(colecao);

    return sucesso;
}
