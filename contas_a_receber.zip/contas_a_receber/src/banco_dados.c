#include <stdio.h>
#include <libpq-fe.h>

#include "banco_dados.h"

PGconn *conectar_banco(void) {
    PGconn *conexao = PQconnectdb(
        "host=localhost "
        "port=5432 "
        "dbname=pim " //Trocar para TorraDB
        "user=postgres "
        "password=123456"
    );
    if (conexao == NULL) {
        fprintf(stderr, "Falha ao alocar a conexão com PostgreSQL.\n");
        return NULL;
    }
    if (PQstatus(conexao) != CONNECTION_OK) {
        fprintf(stderr, "Erro ao conectar ao PostgreSQL: %s",
                PQerrorMessage(conexao));

        PQfinish(conexao);
        return NULL;
    }

    printf("Conexâo com PostgreSQL realizada com sucesso.\n");

    return conexao;
}

void desconectar_banco(PGconn *conexao) {
    if (conexao != NULL) {
        PQfinish(conexao);
    }
}


PGresult *executar_sql(
    PGconn *conexao,
    const char *sql,
    int quantidade_parametros,
    const char *const parametros[]
) {
    if (conexao == NULL || sql == NULL || quantidade_parametros < 0) {
        return NULL;
    }

    if (quantidade_parametros > 0 && parametros == NULL) {
        return NULL;
    }

    PGresult *resultado = PQexecParams(
        conexao,
        sql,
        quantidade_parametros,
        NULL,
        parametros,
        NULL,
        NULL,
        0
    );

    if (resultado == NULL) {
        fprintf(stderr, "Erro ao executar SQL: %s", PQerrorMessage(conexao));
        return NULL;
    }

    ExecStatusType status = PQresultStatus(resultado);

    if (status != PGRES_COMMAND_OK && status != PGRES_TUPLES_OK) {
        fprintf(stderr, "Erro SQL: %s", PQresultErrorMessage(resultado));
        PQclear(resultado);
        return NULL;
    }

    return resultado;
}
