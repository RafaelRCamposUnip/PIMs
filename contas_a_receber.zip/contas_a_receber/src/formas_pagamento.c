#include <stdio.h>
#include "formas_pagamento.h"
#include "banco_dados.h"

int validar_forma_pagamento(
    PGconn *conexao,
    int id_forma_pagamento
) {
    if (conexao == NULL || id_forma_pagamento <= 0) {
        return -1;
    }

    const char *sql =
        "SELECT descricao "
        "FROM vendas.forma_pagamento "
        "WHERE id_forma_pagamento = $1 "
        "AND ativo = TRUE;";

    char id_texto[12];

    snprintf(
        id_texto,
        sizeof(id_texto),
        "%d",
        id_forma_pagamento
    );

    const char *parametros[] = {id_texto};

    PGresult *resultado = executar_sql(
        conexao,
        sql,
        1,
        parametros
    );

    if (resultado == NULL) {
        return -1;
    }

    int valido = PQntuples(resultado) > 0;

    PQclear(resultado);

    return valido;
}