#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <stdint.h>
#include <string.h>

#include "regras_financeiras.h"

#define TAXA_JUROS_MENSAL 5
#define TAXA_MULTA_ATRASO 2

int texto_para_centavos(const char *texto, int64_t *valor_centavos){
    if (valor_centavos == NULL){
        return 0;
    }

    *valor_centavos = 0;

    if (texto == NULL){
        return 0;
    }

    while (isspace((unsigned char)*texto)){
        texto++;
    }

    const char *fim = texto + strlen(texto);

    while (fim > texto && isspace((unsigned char)fim[-1])){
        fim--;
    }

    if (texto == fim){
        return 0;
    }

    uint64_t parte_inteira = 0;
    int digitos_inteiros = 0;
    int digitos_decimais = 0;
    int encontrou_virgula = 0;
    int centavos = 0;

    for (const char *p = texto; p < fim; p++){
        if (*p >= '0' && *p <= '9'){
            int digito = *p - '0';

            if (!encontrou_virgula){
                uint64_t limite = (uint64_t)INT64_MAX / 100;

                if (parte_inteira > (limite - (uint64_t)digito) / 10){
                    return 0;
                }

                parte_inteira = parte_inteira * 10 + (uint64_t)digito;
                digitos_inteiros++;
            }
            else{
                if (digitos_decimais >= 2){
                    return 0;
                }

                centavos = centavos * 10 + digito;
                digitos_decimais++;
            }
        }
        else if ((*p == ',' || *p == '.') && !encontrou_virgula){
            encontrou_virgula = 1;
        }
        else{
            return 0;
        }
    }

    if (digitos_inteiros == 0){
        return 0;
    }

    if (encontrou_virgula && digitos_decimais == 0){
        return 0;
    }

    if (digitos_decimais == 1){
        centavos *= 10;
    }

    if (parte_inteira >((uint64_t)INT64_MAX - (uint64_t)centavos) / 100){
        return 0;
    }

    *valor_centavos = (int64_t)(parte_inteira * 100 + (uint64_t)centavos);
    return 1;
}


int calcular_juros(
    int64_t valor_produto_centavos,
    int quantidade_parcelas,
    int eh_carne,
    int64_t *juros_centavos
){
    if (juros_centavos == NULL){
        return 0;
    }

    *juros_centavos = 0;

    if (valor_produto_centavos < 0 || quantidade_parcelas <= 0 || (eh_carne != 0 && eh_carne != 1)){
        return 0;
    }

    
    if (eh_carne == 0 || quantidade_parcelas < 4){
        return 1;
    }
    

    if (TAXA_JUROS_MENSAL <= 0 || 100 % TAXA_JUROS_MENSAL != 0){
        return 0;
    }

    int divisor_juros = 100 / TAXA_JUROS_MENSAL;

    int64_t parte_inteira = valor_produto_centavos / divisor_juros;
    int64_t resto = valor_produto_centavos % divisor_juros;

    if (parte_inteira > INT64_MAX / quantidade_parcelas){
        return 0;
    }

    int64_t juros_base = parte_inteira * quantidade_parcelas;

    if (resto != 0 && (int64_t)quantidade_parcelas > INT64_MAX / resto) {
        return 0;
    }

    int64_t resto_multiplicado = resto * (int64_t)quantidade_parcelas;

    int64_t juros_adicionais = resto_multiplicado / divisor_juros;

    if ((resto_multiplicado % divisor_juros) * 2 >= divisor_juros){
        juros_adicionais++;
    }

    if (juros_base > INT64_MAX - juros_adicionais){
        return 0;
    }

    *juros_centavos = juros_base + juros_adicionais;

    return 1;

}

int calcular_multa(
    int64_t valor_parcela_centavos,
    int64_t *multa_centavos
){
    if (multa_centavos == NULL){
        return 0;
    }

    *multa_centavos = 0;

    if (valor_parcela_centavos < 0){
        return 0;
    }

    int64_t parte_inteira = valor_parcela_centavos / 100;
    int64_t resto = valor_parcela_centavos % 100;

    if (parte_inteira > INT64_MAX / TAXA_MULTA_ATRASO){
        return 0;
    }

    int64_t multa_base = parte_inteira * TAXA_MULTA_ATRASO;
    int64_t multa_adicional = resto * TAXA_MULTA_ATRASO / 100;

    if ((resto * TAXA_MULTA_ATRASO) % 100 >= 50){
        multa_adicional++;
    }

    if (multa_base > INT64_MAX - multa_adicional){
        return 0;
    }

    *multa_centavos = multa_base + multa_adicional;

    return 1;
}

int calcular_valor_atualizado(
    int64_t valor_nominal_centavos,
    int parcela_atrasada,
    int64_t *valor_atualizado_centavos
){
    if (valor_atualizado_centavos == NULL){
        return 0;
    }

    *valor_atualizado_centavos = 0;

    if (valor_nominal_centavos < 0 || (parcela_atrasada != 0 && parcela_atrasada != 1)){
        return 0;
    }

    if (parcela_atrasada == 0){
        *valor_atualizado_centavos = valor_nominal_centavos;
        return 1;
    }

    int64_t multa_centavos = 0;

    if (!calcular_multa(valor_nominal_centavos, &multa_centavos)){
        return 0;
    }

    if (valor_nominal_centavos > INT64_MAX - multa_centavos){
        return 0;
    }

    *valor_atualizado_centavos = valor_nominal_centavos + multa_centavos;

    return 1;
}

int distribuir_valor_parcelas(
    int64_t valor_total_centavos,
    int quantidade_parcelas,
    int64_t *valores_parcelas
){
    if (valor_total_centavos <= 0 ||
        quantidade_parcelas <= 0 ||
        valores_parcelas == NULL){
        return 0;
    }

    int64_t valor_base = valor_total_centavos / quantidade_parcelas;
    int64_t resto = valor_total_centavos % quantidade_parcelas;

    for (int i = 0; i < quantidade_parcelas; i++){
        valores_parcelas[i] = valor_base;

        if (i < resto){
            valores_parcelas[i]++;
        }
    }

    return 1;
}

int calcular_vencimento_parcela(
    const char *data_venda,
    int numero_parcela,
    char *data_vencimento,
    int tamanho_buffer
){
    if (data_venda == NULL ||
        numero_parcela <= 0 ||
        data_vencimento == NULL ||
        tamanho_buffer < 11){
        return 0;
    }

    int ano, mes, dia;
    char extra;

    if (sscanf(
        data_venda,
        "%4d-%2d-%2d%c",
        &ano, &mes, &dia, &extra
    ) != 3){
        return 0;
    }

    if (ano < 1 || mes < 1 || mes > 12 || dia < 1){
        return 0;
    }

    struct tm data = {0};

    data.tm_year = ano - 1900;
    data.tm_mon = mes - 1;
    data.tm_mday = dia;
    data.tm_hour = 12;

    if (mktime(&data) == (time_t)-1 ||
        data.tm_year != ano - 1900 ||
        data.tm_mon != mes - 1 ||
        data.tm_mday != dia){
        return 0;
    }

    /* Primeiro vencimento: dia seguinte à venda. */
    data.tm_mday++;

    if (mktime(&data) == (time_t)-1){
        return 0;
    }

    /* Calcula o mês da parcela a partir do primeiro vencimento. */
    long long mes_total =
        (long long)data.tm_year * 12 +
        data.tm_mon +
        numero_parcela - 1;

    long long ano_destino = mes_total / 12 + 1900;
    int mes_destino = (int)(mes_total % 12);

    if (ano_destino < 1 || ano_destino > 9999){
        return 0;
    }

    int ultimo_dia;

    if (mes_destino == 1){
        int bissexto =
            (ano_destino % 400 == 0) ||
            (ano_destino % 4 == 0 && ano_destino % 100 != 0);

        ultimo_dia = bissexto ? 29 : 28;
    }
    else if (
        mes_destino == 3 ||
        mes_destino == 5 ||
        mes_destino == 8 ||
        mes_destino == 10
    ){
        ultimo_dia = 30;
    }
    else{
        ultimo_dia = 31;
    }

    int dia_destino = data.tm_mday;

    if (dia_destino > ultimo_dia){
        dia_destino = ultimo_dia;
    }

    data.tm_year = (int)ano_destino - 1900;
    data.tm_mon = mes_destino;
    data.tm_mday = dia_destino;
    data.tm_hour = 12;

    if (mktime(&data) == (time_t)-1){
        return 0;
    }

    if (strftime(
        data_vencimento,
        tamanho_buffer,
        "%Y-%m-%d",
        &data
    ) == 0){
        return 0;
    }

    return 1;
}