#ifndef AUDITORIA_H
#define AUDITORIA_H

#include <mongoc/mongoc.h>
#include <stdint.h>

int registrar_auditoria(
    mongoc_client_t *cliente,
    int id_titulo_receber,
    int id_forma_pagamento,
    const int *ids_parcelas,
    int quantidade_parcelas,
    int64_t valor_total_recebido
);

#endif