#ifndef RECEBIMENTOS_H
#define RECEBIMENTOS_H

#include <libpq-fe.h>
#include <stdint.h>

int registrar_recebimento(
    PGconn *conexao,
    int id_forma_pagamento,
    const int *ids_parcelas,
    int quantidade_parcelas,
    int64_t *valor_total_recebido
);

#endif