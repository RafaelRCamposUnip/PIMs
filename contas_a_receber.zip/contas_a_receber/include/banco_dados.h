#ifndef BANCO_DADOS_H
#define BANCO_DADOS_H

#include <libpq-fe.h>

PGconn *conectar_banco(void);

void desconectar_banco(PGconn *conexao);


PGresult *executar_sql(
    PGconn *conexao,
    const char *sql,
    int quantidade_parametros,
    const char *const parametros[]
);


#endif