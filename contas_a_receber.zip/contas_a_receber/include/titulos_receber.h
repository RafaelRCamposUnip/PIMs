#ifndef TITULOS_RECEBER_H
#define TITULOS_RECEBER_H

#include <libpq-fe.h>

PGresult *consultar_titulo_por_venda_pagamento(
    PGconn *conexao,
    int id_venda_pagamento
);

PGresult *consultar_titulo_por_id(
    PGconn *conexao,
    int id_titulo_receber
);

int validar_consistencia_titulo(
    PGconn *conexao,
    int id_venda_pagamento,
    int id_venda,
    int id_cliente,
    const char *valor_titulo
);

int gerar_parcelas_titulo(
    PGconn *conexao,
    int id_titulo_receber,
    int id_usuario,
    int quantidade_parcelas_solicitada
);

PGresult *consultar_parcelas_titulo(
    PGconn *conexao,
    int id_titulo_receber
);

#endif