#ifndef REGRAS_FINANCEIRAS_H
#define REGRAS_FINANCEIRAS_H

#include <stdint.h>

int texto_para_centavos(const char *texto, int64_t *valor_centavos);

int calcular_juros(
    int64_t valor_produto_centavos,
    int quantidade_parcelas,
    int eh_carne,
    int64_t *juros_centavos
);

int calcular_multa(
    int64_t valor_parcela_centavos,
    int64_t *multa_centavos
);

int calcular_valor_atualizado(
    int64_t valor_nominal_centavos,
    int parcela_atrasada,
    int64_t *valor_atualizado_centavos
);

int distribuir_valor_parcelas(
    int64_t valor_total_centavos,
    int quantidade_parcelas,
    int64_t *valores_parcelas
);

int calcular_vencimento_parcela(
    const char *data_venda,
    int numero_parcela,
    char *data_vencimento,
    int tamanho_buffer
);
#endif