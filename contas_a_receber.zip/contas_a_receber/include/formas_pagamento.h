#ifndef FORMAS_PAGAMENTO_H
#define FORMAS_PAGAMENTO_H

#include <libpq-fe.h>

int validar_forma_pagamento(
    PGconn *conexao,
    int id_forma_pagamento
);

#endif